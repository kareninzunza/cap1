
#include <iostream>

using namespace std;

int main()
{
    //define variable entera llamada x
    int x; // esta variable no está inicializada porque no le hemos dado un valor
    
    // imprime el valor de x en la pantalla
    std :: cout<<x; // quién sabe lo que obtendremos, porque x no está inicializada

    return 0;
}
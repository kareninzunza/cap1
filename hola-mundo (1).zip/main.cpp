
#include <iostream> //for std::cout

int main()
{
    std:: cout <<"Hola" << "Mundo!"; // al utilizar << podemos escribir más de una cosa 
    return 0;
}


#include <iostream>

using namespace std;

int main()
{
    std :: cout << "¡Hola!" << std :: endl; // std :: endl hará que el cursor se mueva a la siguiente línea de consola
    std :: cout <<"Mi nombre es Alex." << std :: endl;

    return 0;
}
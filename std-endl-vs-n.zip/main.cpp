
#include <iostream>

using namespace std;

int main()
{
    int x {5};
    std :: cout << "x es igual a: " << x << '\n'; //usando '\n' independiente
    std :: cout << "¡Y eso es todo, amigos! \n"; // Usar '\n' incrustado en un texto entre comillas dobles

    return 0;
}
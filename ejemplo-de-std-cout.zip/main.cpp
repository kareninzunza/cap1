
#include <iostream>

int main()
{
    int x {5};
    std :: cout << "x es igual a: " <<x;

    return 0;
}
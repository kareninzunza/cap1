
#include <iostream> // para std :: cout y std // cin

using namespace std;

int main()
{
    std :: cout <<"Introduzca un número: "; //pide al usuario un número
    int x {}; // definir la variable x para contener la entrada del usuario (e inicializarla a cero)
    std :: cin >> x;//obtiene el número del teclado y lo almacena en la variable x

    return 0;
}